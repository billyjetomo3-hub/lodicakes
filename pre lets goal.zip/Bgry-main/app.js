"use strict";

/*
 * Barangay Community Help Hub — offline browser demo
 * HTML + CSS + vanilla JS + localStorage.
 * SECURITY: demo-only auth. localStorage is not a secure database and
 * passwords are plain text. Never use for real data.
 */

const STORAGE = {
  requests: "brgy_help_hub_requests_v1",
  announcements: "brgy_help_hub_announcements_v1",
  accounts: "brgy_help_hub_accounts_v1",
  session: "brgy_help_hub_session_v1",
  settings: "brgy_help_hub_settings_v1",
  services: "brgy_help_hub_services_v1",
  counter: "brgy_help_hub_counter_v1"
};

const LEGACY_STORAGE = {
  requests: "brg_requests",
  counter: "brg_request_counter",
  accounts: "brg_demo_accounts",
  session: "brg_demo_session"
};

const DEMO_ADMIN = { email: "admin@example.test", password: "demo-admin-2026", name: "Demo Barangay Admin" };

const DEFAULT_SERVICES = [
  { id: "service-waste", name: "Garbage Collection", category: "Garbage Collection", description: "Missed collection, overflowing bins, or waste concerns." },
  { id: "service-flood", name: "Flooding and Drainage", category: "Flooding / Drainage", description: "Blocked drainage, standing water, or local flooding concerns." },
  { id: "service-streetlight", name: "Broken Streetlight", category: "Broken Streetlight", description: "Broken streetlight or dark public area." },
  { id: "service-health", name: "Health Services", category: "Health Services", description: "Health-service inquiry or community health concern." },
  { id: "service-road", name: "Road and Public Facilities", category: "Road / Public Facility", description: "Road, public facility, or community infrastructure issue." },
  { id: "service-safety", name: "Peace and Safety", category: "Peace and Safety", description: "Community safety or public-order concern." },
  { id: "service-community", name: "Community Concern", category: "Community Concerns", description: "General community concern that needs attention." },
  { id: "service-other", name: "Other Request", category: "Other", description: "Any other community concern." }
];

const DEFAULT_ANNOUNCEMENTS = [
  { title: "Welcome to the Barangay Help Hub", text: "Use this demo website to submit a community concern, keep the reference number, and check the request status.", date: "Sample announcement", category: "General", icon: "⌂" },
  { title: "Keep your surroundings clean", text: "Dispose of waste properly and check verified local collection schedules. Report missed collection using the request form.", date: "Community reminder", category: "Sanitation", icon: "♻" },
  { title: "Verify important community updates", text: "For real schedules, public advisories, or urgent assistance, contact your barangay through verified official channels.", date: "Resident information", category: "Safety", icon: "▤" }
];

const DEFAULT_REQUESTS = [
  { id: "BRG-0001", name: "Demo Resident", contact: "", category: "Garbage Collection", purok: "Purok 3", urgency: "Medium", details: "Sample request: garbage collection follow-up in the area.", status: "Pending", createdAt: "2026-10-20T08:00:00.000Z", updatedAt: "2026-10-20T08:00:00.000Z" },
  { id: "BRG-0002", name: "Demo Resident", contact: "", category: "Broken Streetlight", purok: "Purok 1", urgency: "High", details: "Sample request: a streetlight needs inspection.", status: "In Progress", createdAt: "2026-10-21T09:30:00.000Z", updatedAt: "2026-10-21T09:30:00.000Z" }
];

const STATUSES = ["Pending", "In Progress", "Resolved", "Rejected"];
const URGENCIES = ["Low", "Medium", "High"];
const STATUS_CLASS = { "Pending": "status-pending", "In Progress": "status-progress", "Resolved": "status-resolved", "Rejected": "status-rejected" };
const ROLE_ACCESS = { "help-request": ["resident"], "my-requests": ["resident"], admin: ["admin"] };
const VALID_VIEWS = ["home", "help-request", "my-requests", "track", "services", "announcements", "contacts", "resources", "auth", "admin"];
let adminSection = "overview";
let booted = false;

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

/* -------------------------- Storage helpers -------------------------- */

function safeRead(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value === null ? fallback : JSON.parse(value);
  } catch (error) {
    console.error(`Unable to read "${key}".`, error);
    return fallback;
  }
}

function safeWrite(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.error(`Unable to save "${key}".`, error);
    showToast("Unable to save data. Browser storage may be full or disabled.", "error");
    return false;
  }
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

const normalize = value => String(value ?? "").trim().toLowerCase();

function formatDate(value) {
  if (!value) return "Date unavailable";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Date unavailable";
  return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(date);
}

function getSession() {
  const s = safeRead(STORAGE.session, null);
  return s && typeof s === "object" ? s : null;
}

function getAccounts() {
  const a = safeRead(STORAGE.accounts, []);
  return Array.isArray(a) ? a : [];
}

function getRequests() {
  const stored = safeRead(STORAGE.requests, null);
  if (Array.isArray(stored)) return stored.filter(i => i && typeof i === "object" && typeof i.id === "string");
  const initial = DEFAULT_REQUESTS.map(i => ({ ...i }));
  safeWrite(STORAGE.requests, initial);
  safeWrite(STORAGE.counter, 2);
  return initial;
}

const saveRequests = requests => safeWrite(STORAGE.requests, requests);

function getServices() {
  const stored = safeRead(STORAGE.services, null);
  const fallback = DEFAULT_SERVICES.map(i => ({ ...i }));
  if (Array.isArray(stored) && stored.length) {
    const ok = stored.filter(i => i && i.id && i.name).map(i => ({ ...i }));
    return ok.length ? ok : fallback;
  }
  return fallback;
}

function getAnnouncements() {
  const stored = safeRead(STORAGE.announcements, null);
  if (Array.isArray(stored)) return stored.filter(i => i && i.title && i.text).map(i => ({ ...i })); // empty list allowed
  return DEFAULT_ANNOUNCEMENTS.map(i => ({ ...i }));
}

const saveAnnouncements = list => safeWrite(STORAGE.announcements, list);

function migrateLegacyStorage() {
  [["requests", "requests"], ["counter", "counter"], ["accounts", "accounts"], ["session", "session"]].forEach(([l, n]) => {
    const from = LEGACY_STORAGE[l], to = STORAGE[n];
    if (safeRead(to, null) === null) {
      const legacy = safeRead(from, null);
      if (legacy !== null) {
        safeWrite(to, legacy);
        try { localStorage.removeItem(from); } catch (e) { console.warn(e); }
      }
    }
  });
}

/* -------------------------- Roles -------------------------- */

function getRole() {
  const s = getSession();
  if (!s) return "guest";
  if (s.role === "admin" && normalize(s.email) === normalize(DEMO_ADMIN.email)) return "admin";
  if (s.role === "resident" && getAccounts().some(a => normalize(a.email) === normalize(s.email))) return "resident";
  return "guest";
}
const isDemoAdmin = () => getRole() === "admin";
const isAuthenticatedResident = () => getRole() === "resident";

// Admin sees all; resident sees own; seed/demo records (no owner) are public.
function canView(r) {
  const role = getRole();
  if (role === "admin" || !r.ownerEmail) return true;
  return role === "resident" && normalize(r.ownerEmail) === normalize(getSession().email);
}

function applyRoleUI() {
  const role = getRole();
  $$("[data-roles]").forEach(el => el.classList.toggle("hidden", !el.dataset.roles.split(" ").includes(role)));
  document.body.dataset.role = role;
  const chip = $("#role-chip");
  if (chip) { chip.dataset.role = role; chip.textContent = { guest: "Guest", resident: "Resident", admin: "Admin" }[role]; }
}

/* -------------------------- Sound (WebAudio, no files) -------------------------- */

const Sound = (() => {
  let ctx;
  const enabled = () => (safeRead(STORAGE.settings, {}) || {}).sound !== false;
  function tone(freq, start = 0, dur = .12, type = "sine", vol = .06) {
    if (!enabled()) return;
    try {
      ctx ??= new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === "suspended") ctx.resume().catch(() => {});
      const o = ctx.createOscillator(), g = ctx.createGain(), t = ctx.currentTime + start;
      o.type = type;
      o.frequency.setValueAtTime(freq, t);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol, t + .01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(ctx.destination);
      o.start(t);
      o.stop(t + dur + .02);
    } catch { /* audio blocked */ }
  }
  return {
    click: () => tone(520, 0, .05, "triangle", .035),
    success: () => [523, 659, 784].forEach((f, i) => tone(f, i * .09, .16)),
    warning: () => tone(392, 0, .15, "triangle", .05),
    hover: () => tone(740, 0, .03, "sine", .012),
    tick: () => tone(1000, 0, .02, "square", .01),
    pop: () => { tone(440, 0, .06, "triangle", .05); tone(660, .05, .08, "triangle", .05); },
    whoosh: () => { tone(260, 0, .09, "sine", .03); tone(520, .05, .1, "sine", .025); },
    error: () => { tone(220, 0, .14, "sawtooth", .035); tone(165, .12, .18, "sawtooth", .035); },
    isOn: enabled,
    toggle() {
      const s = safeRead(STORAGE.settings, {}) || {};
      s.sound = s.sound === false; // flips: off -> on, on -> off
      safeWrite(STORAGE.settings, s);
      return s.sound;
    }
  };
})();

function syncSoundButton() {
  const b = $("#sound-toggle");
  if (!b) return;
  b.textContent = Sound.isOn() ? "🔊" : "🔇";
  b.setAttribute("aria-pressed", String(Sound.isOn()));
}

/* -------------------------- Animation helpers -------------------------- */

const reduceMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;

function animateNumber(el, to) {
  if (!el) return;
  const from = Number(el.textContent) || 0;
  if (from === to || reduceMotion()) { el.textContent = to; return; }
  const t0 = performance.now(), dur = 600;
  const step = t => {
    const p = Math.min(1, (t - t0) / dur);
    el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

function ripple(e, btn) {
  if (reduceMotion()) return;
  const r = btn.getBoundingClientRect(), s = document.createElement("span");
  s.className = "ripple";
  s.style.left = e.clientX - r.left + "px";
  s.style.top = e.clientY - r.top + "px";
  btn.appendChild(s);
  setTimeout(() => s.remove(), 600);
}

function burst() {
  if (reduceMotion()) return;
  const colors = ["#0f766e", "#f5d469", "#2458a6", "#9be3b0"];
  for (let i = 0; i < 24; i++) {
    const c = document.createElement("i");
    c.className = "confetti";
    c.style.setProperty("--x", (Math.random() * 2 - 1) * 160 + "px");
    c.style.setProperty("--y", -(Math.random() * 180 + 40) + "px");
    c.style.setProperty("--r", Math.random() * 720 + "deg");
    c.style.background = colors[i % 4];
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 1200);
  }
}

function addHeroParticles() {
  const art = $(".hero-art");
  if (!art || art.dataset.particlesAdded || reduceMotion()) return;
  const colors = ["#9be3b0", "#f5d469", "#ffffff"];
  for (let i = 0; i < 8; i++) {
    const p = document.createElement("div");
    p.className = "particle";
    p.style.left = Math.random() * 100 + "%";
    p.style.top = 40 + Math.random() * 60 + "%";
    p.style.animationDelay = Math.random() * 8 + "s";
    p.style.animationDuration = 6 + Math.random() * 4 + "s";
    p.style.background = colors[i % 3];
    art.appendChild(p);
  }
  art.dataset.particlesAdded = "true";
}

function showToast(message, type = "success") {
  const region = $("#toast-region");
  if (!region) return;
  if (type === "success") Sound.success();
  else if (type === "warning") Sound.warning();
  else Sound.error();

  const toast = document.createElement("div");
  toast.className = `toast${type === "error" ? " error" : type === "warning" ? " warning" : ""}`;
  toast.setAttribute("role", "status");
  toast.textContent = message;
  region.appendChild(toast);
  setTimeout(() => toast.remove(), 4500);
}

/* -------------------------- Navigation -------------------------- */

function navigate(viewName) {
  const role = getRole();
  const allowed = ROLE_ACCESS[viewName];
  if (allowed && !allowed.includes(role)) {
    if (role === "guest") {
      showToast("Mag-login muna bilang Resident.", "warning");
      setAuthTab("login");
      viewName = "auth";
    } else {
      showToast("Hindi para sa role mo ang page na ito.", "error");
      viewName = role === "admin" ? "admin" : "home";
    }
  }

  const target = $(`#view-${viewName}`);
  if (!target) { showToast("That page is not available.", "error"); return; }

  $$(".page-view").forEach(v => v.classList.toggle("hidden", v !== target));
  $$(".nav-btn[data-view]").forEach(b => {
    const active = b.dataset.view === viewName;
    b.classList.toggle("active", active);
    active ? b.setAttribute("aria-current", "page") : b.removeAttribute("aria-current");
  });

  $("#nav-menu")?.classList.remove("open");
  $("#menu-toggle")?.setAttribute("aria-expanded", "false");
  $("#menu-toggle")?.setAttribute("aria-label", "Open navigation menu");

  if (viewName === "admin") { renderAdminTable(); setAdminSection(adminSection); }
  if (viewName === "announcements") renderAnnouncements();
  if (viewName === "auth") renderSessionPanel();
  if (viewName === "my-requests") renderMyRequests();
  if (viewName === "home") { renderHomeStats(); addHeroParticles(); }
  if (viewName === "help-request") {
    const s = getSession(), n = $("#req-name");
    if (n && !n.value && s) n.value = s.name || "";
  }

  if (booted) Sound.whoosh();
  history.replaceState(null, "", `#${viewName}`);
  window.scrollTo({ top: 0, behavior: reduceMotion() ? "auto" : "smooth" });
}

function handleNavigationClick(event) {
  const button = event.target.closest("[data-view]");
  if (!button) return;
  const viewName = button.dataset.view;
  if (!viewName) return;
  if (button.tagName === "A") event.preventDefault();

  const category = button.dataset.category;
  if (category && $("#req-category")) $("#req-category").value = category;

  navigate(viewName);
}

function setupNavigation() {
  document.addEventListener("click", handleNavigationClick);
  $("#menu-toggle")?.addEventListener("click", () => {
    const menu = $("#nav-menu"), button = $("#menu-toggle");
    const isOpen = menu.classList.toggle("open");
    button.setAttribute("aria-expanded", String(isOpen));
    button.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
  });
}

/* -------------------------- Request submission -------------------------- */

function createRequestId(requests) {
  const stored = Number(safeRead(STORAGE.counter, 0)) || 0;
  const highest = requests.reduce((h, r) => {
    const m = /^BRG-(\d+)$/i.exec(String(r.id || ""));
    return m ? Math.max(h, Number(m[1])) : h;
  }, 0);
  return `BRG-${String(Math.max(stored, highest) + 1).padStart(4, "0")}`;
}

function showRequestMessage(message, type = "success") {
  const el = $("#request-form-message");
  if (!el) return;
  el.textContent = message;
  el.classList.toggle("error", type === "error");
}

function handleHelpRequestSubmit(event) {
  event.preventDefault();
  if (!isAuthenticatedResident()) { navigate("help-request"); return; }
  const session = getSession();

  const form = $("#help-request-form");
  if (!form || !form.reportValidity()) return;

  const name = $("#req-name").value.trim();
  const contact = $("#req-contact").value.trim();
  const category = $("#req-category").value;
  const purok = $("#req-purok").value.trim();
  const urgency = $("#req-urgency").value;
  const details = $("#req-details").value.trim();
  const consent = $("#req-consent").checked;

  if (!name || !category || !purok || !details) return showRequestMessage("Please complete all required fields.", "error");
  if (!URGENCIES.includes(urgency)) return showRequestMessage("Please select a valid urgency level.", "error");
  if (!consent) return showRequestMessage("Please confirm the demo privacy notice.", "error");

  const requests = getRequests();

  // Duplicate warning: only against requests this user may see.
  const duplicate = requests.find(r =>
    canView(r) &&
    normalize(r.category) === normalize(category) &&
    normalize(r.purok) === normalize(purok) &&
    ["Pending", "In Progress"].includes(r.status)
  );
  if (duplicate && !window.confirm(`A similar active request already exists (${duplicate.id}).\n\nDo you still want to submit another request?`)) return;

  const id = createRequestId(requests);
  const now = new Date().toISOString();
  const request = {
    id, name, contact, category, purok, urgency, details,
    status: "Pending", createdAt: now, updatedAt: now,
    ownerEmail: session.email, ownerName: session.name
  };

  if (!saveRequests([...requests, request])) return showRequestMessage("Your request could not be saved. Check browser storage and try again.", "error");
  safeWrite(STORAGE.counter, Number(id.replace(/^BRG-/i, "")));

  form.reset();
  updateDetailsCount();
  showRequestMessage(`Your request was saved. Your ID is ${id}.`);

  if ($("#track-id")) $("#track-id").value = id;
  renderMyRequests();
  renderHomeStats();
  renderTrackResult(request);
  burst();
  showToast(`Request ${id} was saved successfully.`);
  navigate("track");
}

/* -------------------------- Tracking -------------------------- */

function renderTrackResult(request) {
  const result = $("#track-result");
  if (!result) return;

  if (!request) {
    result.innerHTML = `<div class="notice notice-warning"><strong>Request not found</strong><p>Check the reference number and try again. The number must match a request you are allowed to view.</p></div>`;
    return;
  }

  const steps = ["Pending", "In Progress", "Resolved"];
  const current = steps.indexOf(request.status);
  const timeline = request.status === "Rejected"
    ? `<span class="timeline-step done">Submitted</span><span class="timeline-step rejected-step">Rejected</span>`
    : steps.map((s, i) => `<span class="timeline-step${i <= current ? " done" : ""}"${s === request.status ? ' aria-current="step"' : ""}>${escapeHTML(s)}</span>`).join("");

  result.innerHTML = `
    <article class="result-card">
      <div class="result-head">
        <div>
          <span class="eyebrow">REQUEST REFERENCE</span>
          <h2 class="result-id">${escapeHTML(request.id)}</h2>
          <p class="field-hint">Submitted ${escapeHTML(formatDate(request.createdAt))}</p>
        </div>
        <span class="status-pill ${STATUS_CLASS[request.status] || "status-pending"}">${escapeHTML(request.status)}</span>
      </div>
      <div class="result-meta">
        <div><small>Category</small><strong>${escapeHTML(request.category)}</strong></div>
        <div><small>Area</small><strong>${escapeHTML(request.purok)}</strong></div>
        <div><small>Urgency</small><strong>${escapeHTML(request.urgency)}</strong></div>
        <div><small>Last updated</small><strong>${escapeHTML(formatDate(request.updatedAt))}</strong></div>
      </div>
      <div class="result-description">${escapeHTML(request.details)}</div>
      <div><strong>Status progress</strong><div class="timeline">${timeline}</div></div>
      <p class="field-hint">This status is stored in this browser's demo data and is not an official barangay case update.</p>
    </article>`;
}

function handleTrackSubmit(event) {
  event.preventDefault();
  if (!$("#track-form").reportValidity()) return;
  const id = $("#track-id").value.trim().toUpperCase();
  const request = getRequests().find(r => r.id.toUpperCase() === id && canView(r));
  renderTrackResult(request);
  request ? showToast(`Showing request ${request.id}.`) : showToast("No matching request was found.", "error");
}

function openTracked(id) {
  const r = getRequests().find(x => x.id === id && canView(x));
  if ($("#track-id")) $("#track-id").value = id;
  renderTrackResult(r);
  navigate("track");
}

/* -------------------------- Resident: My Requests -------------------------- */

function renderMyRequests() {
  const box = $("#my-requests-list"), s = getSession();
  if (!box) return;
  const mine = getRequests()
    .filter(r => s && normalize(r.ownerEmail) === normalize(s.email))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  if (!mine.length) {
    box.innerHTML = `<div class="empty-state"><span>▤</span><h3>Wala ka pang request</h3><p>Mag-submit ng bago para lumabas dito.</p></div>`;
    return;
  }
  box.innerHTML = mine.map(r => `
    <article class="announcement-card">
      <span class="announcement-symbol" aria-hidden="true">▤</span>
      <div>
        <h3>${escapeHTML(r.id)} · ${escapeHTML(r.category)}</h3>
        <p>${escapeHTML(r.details)}</p>
        <small>${escapeHTML(formatDate(r.createdAt))} · ${escapeHTML(r.purok)}</small>
        <p><span class="status-pill ${STATUS_CLASS[r.status] || "status-pending"}">${escapeHTML(r.status)}</span>
        <button class="text-link" type="button" data-track="${escapeHTML(r.id)}">Details →</button></p>
      </div>
    </article>`).join("");
}

/* -------------------------- Admin: requests -------------------------- */

function getFilteredRequests() {
  const search = normalize($("#admin-search")?.value);
  const status = $("#admin-filter")?.value || "all";
  const urgency = $("#urgency-filter")?.value || "all";

  return getRequests()
    .filter(r => {
      const text = [r.id, r.name, r.contact, r.category, r.purok, r.details, r.urgency, r.status, r.ownerEmail].map(normalize).join(" ");
      return (!search || text.includes(search)) &&
        (status === "all" || r.status === status) &&
        (urgency === "all" || r.urgency === urgency);
    })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function renderAdminStats() {
  const r = getRequests(), n = s => r.filter(x => x.status === s).length;
  animateNumber($("#stat-total"), r.length);
  animateNumber($("#stat-pending"), n("Pending"));
  animateNumber($("#stat-progress"), n("In Progress"));
  animateNumber($("#stat-resolved"), n("Resolved"));
}

function renderAdminTable() {
  const tbody = $("#admin-table-body");
  if (!tbody) return;
  renderAdminStats();

  const requests = getFilteredRequests();
  tbody.innerHTML = "";

  requests.forEach(r => {
    const row = document.createElement("tr");
    const urgencyClass = r.urgency === "High" ? "status-rejected" : r.urgency === "Medium" ? "status-pending" : "status-progress";
    const options = STATUSES.map(s => `<option value="${escapeHTML(s)}"${r.status === s ? " selected" : ""}>${escapeHTML(s)}</option>`).join("");
    const sid = escapeHTML(r.id);

    row.innerHTML = `
      <td><strong>${sid}</strong><small>${escapeHTML(formatDate(r.createdAt))}</small><small>${escapeHTML(r.ownerEmail || "Demo seed")}</small></td>
      <td><strong>${escapeHTML(r.category)}</strong><small>${escapeHTML(r.name)}</small><small>${escapeHTML(r.details)}</small></td>
      <td>${escapeHTML(r.purok)}</td>
      <td><span class="status-pill ${urgencyClass}">${escapeHTML(r.urgency)}</span></td>
      <td><span class="status-pill ${STATUS_CLASS[r.status] || "status-pending"}">${escapeHTML(r.status)}</span></td>
      <td>
        <label class="field-hint" for="status-${sid}">Change status</label>
        <select class="table-status" id="status-${sid}" data-status-id="${sid}" aria-label="Update status for ${sid}">${options}</select>
      </td>`;
    tbody.appendChild(row);
  });

  $("#admin-results-count").textContent = `Showing ${requests.length} of ${getRequests().length} request(s).`;
  $("#admin-empty").classList.toggle("hidden", requests.length > 0);
  tbody.closest("table").classList.toggle("hidden", requests.length === 0);
}

function handleStatusChange(event) {
  const select = event.target.closest("[data-status-id]");
  if (!select) return;

  if (!isDemoAdmin()) { showToast("Admin lang.", "error"); renderAdminTable(); return; }

  const id = select.dataset.statusId, newStatus = select.value;
  if (!STATUSES.includes(newStatus)) { showToast("Invalid status selected.", "error"); renderAdminTable(); return; }

  const requests = getRequests();
  const index = requests.findIndex(r => r.id === id);
  if (index < 0) { showToast("This request no longer exists.", "error"); renderAdminTable(); return; }
  if (requests[index].status === newStatus) return;

  requests[index] = { ...requests[index], status: newStatus, updatedAt: new Date().toISOString() };
  if (!saveRequests(requests)) { renderAdminTable(); return; }

  renderAdminTable();
  $(`#status-${CSS.escape(id)}`)?.closest("tr")?.classList.add("row-flash");

  if (normalize($("#track-id")?.value) === normalize(id)) renderTrackResult(requests[index]);
  renderHomeStats();
  showToast(`${id} updated to ${newStatus}.`);
}

function clearFilters() {
  $("#admin-search").value = "";
  $("#admin-filter").value = "all";
  $("#urgency-filter").value = "all";
  renderAdminTable();
  showToast("Filters cleared.");
}

function exportDataBackup() {
  if (!isDemoAdmin()) { showToast("Admin lang.", "error"); return; }
  const payload = {
    exportedAt: new Date().toISOString(),
    application: "Barangay Community Help Hub Demo",
    warning: "Browser demo data only. This export is not an official record.",
    requests: getRequests(),
    announcements: getAnnouncements(),
    demoAccounts: getAccounts().map(({ password, ...safe }) => safe) // never export passwords
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `barangay-help-hub-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast("JSON backup exported.");
}

function clearDemoData() {
  if (!isDemoAdmin()) { showToast("Admin lang.", "error"); return; }
  if (!window.confirm("Clear ALL demo requests stored in this browser?\n\nThis cannot be undone. Demo accounts will not be deleted.")) return;
  if (!saveRequests([]) || !safeWrite(STORAGE.counter, 0)) return;
  $("#track-result").innerHTML = "";
  renderAdminTable();
  renderMyRequests();
  renderHomeStats();
  showToast("All demo requests have been cleared.", "warning");
}

/* -------------------------- Admin: sections -------------------------- */

function setAdminSection(name) {
  adminSection = name;
  $$(".admin-section").forEach(s => s.classList.toggle("hidden", s.dataset.section !== name));
  $$("[data-admin-section]").forEach(b => b.classList.toggle("active", b.dataset.adminSection === name));
  if (name === "overview") renderAdminStats();
  if (name === "reports") renderReports();
  if (name === "announcements") renderAdminAnnouncements();
}

function renderAdminAnnouncements() {
  const box = $("#admin-announcements-list");
  if (!box) return;
  const items = getAnnouncements();
  box.innerHTML = items.length ? items.map((a, i) => `
    <article class="announcement-card">
      <span class="announcement-symbol" aria-hidden="true">${escapeHTML(a.icon || "▤")}</span>
      <div style="flex:1">
        <h3>${escapeHTML(a.title)}</h3><p>${escapeHTML(a.text)}</p>
        <small>${escapeHTML(a.date || "Community update")} · ${escapeHTML(a.category || "General")}</small>
      </div>
      <button class="btn btn-danger-outline" type="button" data-del-ann="${i}">Delete</button>
    </article>`).join("")
    : `<div class="empty-state"><span>⌗</span><h3>Walang announcement</h3></div>`;
}

function handleAnnouncementSubmit(e) {
  e.preventDefault();
  if (!isDemoAdmin()) return showToast("Admin lang.", "error");
  const title = $("#ann-title").value.trim(), text = $("#ann-text").value.trim();
  if (!title || !text) return showToast("Kumpletuhin ang title at message.", "error");

  const list = getAnnouncements();
  list.unshift({
    title, text, category: $("#ann-category").value, icon: "▤",
    date: new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(new Date())
  });
  if (!saveAnnouncements(list)) return;
  e.target.reset();
  renderAdminAnnouncements(); renderAnnouncements(); renderHomeStats();
  showToast("Announcement published.");
}

function deleteAnnouncement(i) {
  if (!isDemoAdmin() || !window.confirm("Delete this announcement?")) return;
  const list = getAnnouncements();
  list.splice(i, 1);
  if (!saveAnnouncements(list)) return;
  renderAdminAnnouncements(); renderAnnouncements(); renderHomeStats();
  showToast("Announcement deleted.", "warning");
}

function renderReports() {
  const box = $("#reports-body");
  if (!box) return;
  const reqs = getRequests(), total = reqs.length || 1;
  const count = key => reqs.reduce((m, r) => ((m[r[key]] = (m[r[key]] || 0) + 1), m), {});
  const bars = obj => Object.entries(obj).sort((a, b) => b[1] - a[1]).map(([k, v]) => `
    <div class="bar-row"><span>${escapeHTML(k)}</span><div class="bar"><i style="--w:${Math.round(v / total * 100)}%"></i></div><b>${v}</b></div>`).join("")
    || `<p class="field-hint">Walang data.</p>`;
  const rate = Math.round(reqs.filter(r => r.status === "Resolved").length / total * 100);

  box.innerHTML = `
    <div class="panel"><h3>By category</h3>${bars(count("category"))}</div>
    <div class="panel"><h3>By urgency</h3>${bars(count("urgency"))}</div>
    <div class="panel"><h3>By status</h3>${bars(count("status"))}<p class="field-hint">Resolution rate: <strong>${rate}%</strong></p></div>`;
}

/* -------------------------- Auth (demo only) -------------------------- */

function setAuthTab(tab) {
  const login = tab === "login";
  $("#tab-login")?.classList.toggle("active", login);
  $("#tab-register")?.classList.toggle("active", !login);
  $("#tab-login")?.setAttribute("aria-selected", String(login));
  $("#tab-register")?.setAttribute("aria-selected", String(!login));
  $("#login-form")?.classList.toggle("hidden", !login);
  $("#register-form")?.classList.toggle("hidden", login);
}

function setMessage(selector, message, type = "success") {
  const el = $(selector);
  if (!el) return;
  el.textContent = message;
  el.classList.toggle("error", type === "error");
}

function handleRegister(event) {
  event.preventDefault();
  const form = $("#register-form");
  if (!form.reportValidity()) return;

  const name = $("#register-name").value.trim();
  const email = normalize($("#register-email").value);
  const password = $("#register-password").value;

  if (!name || !email || password.length < 8) return setMessage("#register-message", "Complete the required fields. Password must be at least 8 characters.", "error");
  if (password !== $("#register-confirm").value) return setMessage("#register-message", "Passwords do not match.", "error");
  if (!$("#register-consent").checked) return setMessage("#register-message", "Please accept the demo account notice.", "error");
  if (email === normalize(DEMO_ADMIN.email)) return setMessage("#register-message", "This email is reserved for the demo admin.", "error");

  const accounts = getAccounts();
  if (accounts.some(a => normalize(a.email) === email)) return setMessage("#register-message", "An account with this email already exists in this browser.", "error");

  const account = { id: `demo-${Date.now()}`, name, email, password, role: "resident", createdAt: new Date().toISOString() };
  if (!safeWrite(STORAGE.accounts, [...accounts, account])) return;

  form.reset();
  setMessage("#register-message", "Demo account created. You can now log in.");
  showToast("Demo account created.");
  setAuthTab("login");
  $("#login-email").value = email;
}

function handleLogin(event) {
  event.preventDefault();
  if (!$("#login-form").reportValidity()) return;

  const email = normalize($("#login-email").value);
  const password = $("#login-password").value;
  const requestedRole = $("#login-role").value;

  if (requestedRole === "admin") {
    if (email !== normalize(DEMO_ADMIN.email) || password !== DEMO_ADMIN.password) {
      return setMessage("#login-message", "The configured demo administrator credentials are required.", "error");
    }
    if (!safeWrite(STORAGE.session, { name: DEMO_ADMIN.name, email: DEMO_ADMIN.email, role: "admin", startedAt: new Date().toISOString() })) return;
    setMessage("#login-message", "Demo admin session started.");
    $("#login-form").reset();
    renderSessionPanel();
    showToast("Demo admin session started.");
    navigate("admin");
    return;
  }

  const account = getAccounts().find(a => normalize(a.email) === email && a.password === password && a.role === "resident");
  if (!account) return setMessage("#login-message", "Demo login failed. Check your email and password, or register a demo account.", "error");

  if (!safeWrite(STORAGE.session, { name: account.name, email: account.email, role: "resident", startedAt: new Date().toISOString() })) return;
  setMessage("#login-message", "You are signed in to the local demo.");
  $("#login-form").reset();
  renderSessionPanel();
  renderMyRequests();
  showToast("Demo login successful.");
  navigate("home");
}

function logout() {
  try { localStorage.removeItem(STORAGE.session); } catch (e) { console.error(e); }
  if ($("#track-result")) $("#track-result").innerHTML = "";
  adminSection = "overview";
  renderSessionPanel();
  showToast("You have logged out of the demo.", "warning");
  navigate("home");
}

function renderSessionPanel() {
  applyRoleUI();
  const session = getSession(), panel = $("#session-panel");
  if (!panel) return;
  const role = getRole();
  panel.classList.toggle("hidden", role === "guest");
  if (role === "guest") { $("#session-info").textContent = ""; return; }
  $("#session-info").textContent = `Signed in as ${session.name} (${role}). This session is for demo purposes only.`;
  $("#session-admin-btn").classList.toggle("hidden", role !== "admin");
}

/* -------------------------- Public renders -------------------------- */

function renderAnnouncements() {
  const container = $("#announcements-list");
  if (!container) return;
  const search = normalize($("#announcement-search")?.value);
  const items = getAnnouncements().filter(i => !search || `${i.title} ${i.text} ${i.category || ""}`.toLowerCase().includes(search));

  if (!items.length) {
    container.innerHTML = `<div class="empty-state"><span>⌗</span><h3>No announcements found</h3><p>Try a different search term.</p></div>`;
    return;
  }
  container.innerHTML = items.map(i => `
    <article class="announcement-card">
      <span class="announcement-symbol" aria-hidden="true">${escapeHTML(i.icon || "⌂")}</span>
      <div>
        <h3>${escapeHTML(i.title)}</h3>
        <p>${escapeHTML(i.text)}</p>
        <small>${escapeHTML(i.date || "Community update")} · ${escapeHTML(i.category || "General")}</small>
      </div>
    </article>`).join("");
}

function renderHomeStats() {
  const requests = getRequests();
  const set = (sel, v) => animateNumber($(sel), Number(v) || 0);
  set("#home-services-count", getServices().length);
  set("#home-requests-count", requests.length);
  set("#home-resolved-count", requests.filter(r => r.status === "Resolved").length);
  set("#home-announcements-count", getAnnouncements().length);
}

function renderServices() {
  const container = $("#services-list");
  if (!container) return;
  const search = normalize($("#service-search")?.value);
  const services = getServices().filter(s => !search || `${s.name} ${s.category} ${s.description}`.toLowerCase().includes(search));

  if (!services.length) {
    container.innerHTML = `<div class="empty-state"><span>⌗</span><h3>No services found</h3><p>Try a different search term.</p></div>`;
    return;
  }
  container.innerHTML = services.map(s => `
    <article class="feature-card service-card" data-service-id="${escapeHTML(s.id)}">
      <span class="feature-icon teal-icon">▤</span>
      <h3>${escapeHTML(s.name)}</h3>
      <p>${escapeHTML(s.description)}</p>
      <button class="text-link" type="button" data-category="${escapeHTML(s.category)}" data-view="help-request">Report this concern →</button>
    </article>`).join("");
}

function updateDetailsCount() {
  const t = $("#req-details"), c = $("#details-count");
  if (t && c) c.textContent = t.value.length;
}

function setupAccessibilityShortcuts() {
  // Alt+1 larger text, Alt+2 smaller text, Alt+H high contrast.
  let fontSize = 17;
  document.addEventListener("keydown", e => {
    if (!e.altKey) return;
    if (e.key === "1") fontSize = Math.min(24, fontSize + 1);
    else if (e.key === "2") fontSize = Math.max(14, fontSize - 1);
    else if (e.key.toLowerCase() === "h") { document.body.classList.toggle("high-contrast"); return; }
    else return;
    document.documentElement.style.setProperty("--font-base", `${fontSize}px`);
  });
}

/* -------------------------- Init -------------------------- */

function initializeDemoStorage() {
  migrateLegacyStorage();
  if (safeRead(STORAGE.requests, null) === null) {
    safeWrite(STORAGE.requests, DEFAULT_REQUESTS.map(i => ({ ...i })));
    safeWrite(STORAGE.counter, 2);
  }
}

function setupEventListeners() {
  $("#help-request-form")?.addEventListener("submit", handleHelpRequestSubmit);
  $("#track-form")?.addEventListener("submit", handleTrackSubmit);
  $("#login-form")?.addEventListener("submit", handleLogin);
  $("#register-form")?.addEventListener("submit", handleRegister);
  $("#announcement-form")?.addEventListener("submit", handleAnnouncementSubmit);

  $("#req-details")?.addEventListener("input", updateDetailsCount);
  $("#help-request-form")?.addEventListener("reset", () => setTimeout(() => { updateDetailsCount(); showRequestMessage(""); }, 0));

  $("#tab-login")?.addEventListener("click", () => setAuthTab("login"));
  $("#tab-register")?.addEventListener("click", () => setAuthTab("register"));
  $("#logout-btn")?.addEventListener("click", logout);
  $("#admin-logout")?.addEventListener("click", logout);

  $("#admin-search")?.addEventListener("input", renderAdminTable);
  $("#admin-filter")?.addEventListener("change", renderAdminTable);
  $("#urgency-filter")?.addEventListener("change", renderAdminTable);
  $("#admin-table-body")?.addEventListener("change", handleStatusChange);

  $("#announcement-search")?.addEventListener("input", renderAnnouncements);
  $("#service-search")?.addEventListener("input", renderServices);

  $("#refresh-admin")?.addEventListener("click", () => { renderAdminTable(); showToast("Dashboard refreshed."); });
  $("#clear-filters")?.addEventListener("click", clearFilters);
  $("#export-data")?.addEventListener("click", exportDataBackup);
  $("#clear-demo-data")?.addEventListener("click", clearDemoData);

  // Global delegated clicks: sound, ripple, admin sections, tracking, delete.
  document.addEventListener("click", e => {
    if (e.target.closest("button, .btn, a")) Sound.click();
    const btn = e.target.closest(".btn");
    if (btn) ripple(e, btn);
    const sec = e.target.closest("[data-admin-section]");
    if (sec) setAdminSection(sec.dataset.adminSection);
    const trk = e.target.closest("[data-track]");
    if (trk) openTracked(trk.dataset.track);
    const del = e.target.closest("[data-del-ann]");
    if (del) deleteAnnouncement(Number(del.dataset.delAnn));
  });

  $("#sound-toggle")?.addEventListener("click", () => {
    const on = Sound.toggle();
    syncSoundButton();
    if (on) Sound.success();
  });

  window.addEventListener("hashchange", () => {
    const v = location.hash.replace(/^#/, "");
    if (VALID_VIEWS.includes(v)) navigate(v);
  });
}

/* -------------------------- FX: theme, reveal, spotlight, sounds -------------------------- */

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const b = $("#theme-toggle");
  if (b) { b.textContent = theme === "dark" ? "🌙" : "☀️"; b.setAttribute("aria-pressed", String(theme === "light")); }
  $('meta[name="theme-color"]')?.setAttribute("content", theme === "dark" ? "#051c1a" : "#f1f7f6");
}

function toggleTheme() {
  const s = safeRead(STORAGE.settings, {}) || {};
  s.theme = (s.theme || "dark") === "dark" ? "light" : "dark";
  safeWrite(STORAGE.settings, s);
  applyTheme(s.theme);
  Sound.pop();
}

const REVEAL_SEL = ".section-heading, .feature-card, .stat-card, .announcement-card, .result-card, .panel, .notice, .empty-state, .step-row";
let revealIO, revealQueued = false;

function revealScan() {
  if (!("IntersectionObserver" in window) || reduceMotion()) return;
  document.documentElement.classList.add("js-reveal");
  revealIO ??= new IntersectionObserver(entries => entries.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add("in"); revealIO.unobserve(e.target); }
  }), { threshold: .1 });
  $$(REVEAL_SEL).forEach(el => {
    if (el.dataset.rv) return;
    el.dataset.rv = "1";
    el.classList.add("rv");
    el.style.setProperty("--d", Math.min([...el.parentElement.children].indexOf(el), 8) * 70 + "ms");
    revealIO.observe(el);
  });
}

function setupFX() {
  applyTheme((safeRead(STORAGE.settings, {}) || {}).theme || "dark");
  $("#theme-toggle")?.addEventListener("click", toggleTheme);

  // Re-scan for scroll-reveal whenever content is (re)rendered.
  const main = $("#main-content");
  if (main) new MutationObserver(() => {
    if (revealQueued) return;
    revealQueued = true;
    requestAnimationFrame(() => { revealQueued = false; revealScan(); });
  }).observe(main, { childList: true, subtree: true });
  revealScan();

  // Card spotlight follows the pointer.
  let frame = 0;
  document.addEventListener("pointermove", e => {
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      const card = e.target.closest?.(".feature-card, .stat-card, .announcement-card, .panel, .result-card");
      if (!card) return;
      const r = card.getBoundingClientRect();
      card.style.setProperty("--mx", e.clientX - r.left + "px");
      card.style.setProperty("--my", e.clientY - r.top + "px");
    });
  }, { passive: true });

  // Soft hover tick (mouse only) and typing tick.
  let lastHover = null;
  document.addEventListener("pointerover", e => {
    if (e.pointerType !== "mouse") return;
    const t = e.target.closest?.(".btn, .nav-btn, .admin-side-link, .feature-card, .text-link") || null;
    if (t && t !== lastHover) Sound.hover();
    lastHover = t;
  });
  let lastTick = 0;
  document.addEventListener("input", e => {
    if (!e.target.matches("input:not([type=checkbox]), textarea")) return;
    const now = performance.now();
    if (now - lastTick > 55) { Sound.tick(); lastTick = now; }
  });

  // Scroll progress bar.
  const bar = $("#scroll-progress");
  if (bar) addEventListener("scroll", () => {
    const d = document.documentElement;
    bar.style.transform = `scaleX(${d.scrollTop / ((d.scrollHeight - d.clientHeight) || 1)})`;
  }, { passive: true });
}

function initializeApp() {
  initializeDemoStorage();
  setupFX();
  setupNavigation();
  setupEventListeners();
  setupAccessibilityShortcuts();
  updateDetailsCount();
  renderHomeStats();
  renderServices();
  renderAnnouncements();
  renderAdminTable();
  syncSoundButton();
  renderMyRequests();
  renderSessionPanel();

  const requested = location.hash.replace(/^#/, "");
  navigate(VALID_VIEWS.includes(requested) ? requested : "home");
  booted = true;
}

document.addEventListener("DOMContentLoaded", initializeApp);