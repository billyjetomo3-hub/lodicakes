# BRGY Community Help Hub

A responsive, browser-only community service demonstration built with HTML5, CSS3, vanilla JavaScript, inline/local SVG assets, and LocalStorage.

## Run locally

Open `index.html` directly in a modern browser. No build step, server, package manager, or external API is required.

## Demo features

- Submit and track community requests
- Local request status updates
- Public announcements and service directory
- Demo registration/login flow
- Demo administrator request table and JSON export
- Coordinated public and dashboard logos
- Responsive layout and reduced-motion support

## Demo limitations

This is not a production government system. LocalStorage is not secure, authoritative, or synchronized between browsers/devices. Do not enter real passwords, sensitive personal data, or official records. Authentication and administrator controls are demonstration-only and can be modified by anyone with browser developer tools. Verify all contacts, schedules, and urgent instructions through official local channels.

## Storage

Current versioned keys use the `brgy_help_hub_*_v1` namespace. The app migrates the earlier `brg_*` request/account/session keys locally when found, without contacting any external service.
